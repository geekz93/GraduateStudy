% PAYMENT -- No Charge for WaveLab Software
%
%  WaveLab software is available at NO CHARGE 
%	by www access from http://www-stat.stanford.edu/~wavelab
%
%  The software is copyrighted. For permissions to copy, see
%  the file COPYING.m or e-mail wavelab@stat.stanford.edu
%
%  If you use this software to produce scientific articles, we
%  would appreciate being informed of the article's title, authors,
%  topic, and place of appearance.
%
%  If this software played a major enabling role in your scientific work,
%  and you are so moved, you might acknowedge us in your article. 
% 
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:40 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
