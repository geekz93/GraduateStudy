% REGISTRATION -- WaveLab Registration
%
%    Please Register yourself as a user of WaveLab so that we can send
%        you e-mail about upgrades and enhancements.
%    To Register:  
%        e-mail  wavelab@stat.stanford.edu, 
%                with subject line ``registration''
%  
%    If you like, please include information about the version of MATLAB
%    you are using and about the type of machine you are using.
%
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:40 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
